package de.dhbw.wwieeg22spring.controller;

import lombok.Getter;
import java.time.LocalDate;

import org.springframework.stereotype.Component;

@Component

public class BlogEntry {
    private long id;
    // Getter-Methode für die Eigenschaft "title"
    @Getter
    private String title;
    // Getter-Methode für die Eigenschaft "content"
    @Getter
    private String content;
    // Getter-Methode für die Eigenschaft "creationDate"
    @Getter
    private LocalDate creationDate=LocalDate.now(); //i used here java.util.Date u can also use java.time.LocalDate. Therefore the year starts to count 1900 and january is the 0 month.
    @Getter
    private String author;


    // Getter-Methode für die Eigenschaft "id"
    public Long getId() {
        return id;
    }

    // Setter-Methode für die Eigenschaft "id"
    public void setId(Long id) {
        this.id = id;
    }

    // Setter-Methode für die Eigenschaft "title"
    public void setTitle(String title) {
        this.title = title;
    }

    // Setter-Methode für die Eigenschaft "content"
    public void setContent(String content) {
        this.content = content;
    }

    public String setAuthor(String author) {
        this.author = author;
        return author;
    }

    // Setter-Methode für die Eigenschaft "creationDate"
    public void setCreationDate(LocalDate creationDate) {
        this.creationDate = creationDate;
    }
}


