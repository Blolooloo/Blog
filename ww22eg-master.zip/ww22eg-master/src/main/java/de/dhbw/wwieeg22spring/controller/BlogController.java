package de.dhbw.wwieeg22spring.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.time.LocalDate;
import java.util.List;

@RestController
public class BlogController {
    private final List<BlogEntry> blogEntries = new ArrayList<>();

    public BlogController() {
        // Automatisches Hinzufügen von 3 Blog-Einträgen beim Initialisieren der Klasse
        for (int i = 1; i <= 3; i++) {
            BlogEntry entry = new BlogEntry();
            entry.setId((long) i);
            entry.setAuthor("Name");
            entry.setTitle("Meine Reise Part " + i);
            entry.setContent("Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. ");
            entry.setAuthor("Stella");
            entry.setCreationDate(LocalDate.of(2006,5,2));
            blogEntries.add(entry);
        }
    }

    @GetMapping("/blog-entries")
    public List<BlogEntry> getBlogEntries() {
        return blogEntries;
    }

    @PostMapping("/blog-entries")
    public BlogEntry createBlogEntry(@RequestBody BlogEntry blogEntry) {
        // Füge den Blog-Eintrag zur Liste hinzu
// Ändern Sie das Datum auf die aktuelle Uhrzeit
        blogEntry.setCreationDate(LocalDate.now());
        blogEntries.add(blogEntry);
        return blogEntry;
    }

}

