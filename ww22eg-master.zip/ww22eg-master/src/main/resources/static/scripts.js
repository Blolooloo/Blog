// ...
fetch('/blog-entries', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify({ title, author, content })
})
    .then(response => response.json())
    .then(data => {
        data.creationDate = new Date(data.creationDate); // Hinzugefügt
        console.log(data); // Hinzugefügt für Debugging-Zwecke

        // Aktualisiere die Benutzeroberfläche, um den neuen Eintrag anzuzeigen
        const blogEntries = document.getElementById('blog-entries');
        const entryDiv = document.createElement('div');
        entryDiv.innerHTML = `
            <h3>${data.title}</h3>
            <p>Author:${data.author}</p>
            <p>${data.content}</p>
            <p>Created on: ${data.creationDate ? data.creationDate.toLocaleString() : ''}</p>

        `;
        blogEntries.appendChild(entryDiv);
        // Leere die Eingabefelder
        document.getElementById('title').value = '';
        document.getElementById('author').value = '';
        document.getElementById('content').value = '';

        // Lade die Blog-Einträge sofort neu
        loadBlogEntries();
    });

function loadBlogEntries() {
    // Lade die Blog-Einträge beim Seitenladen
    fetch('/blog-entries')
        .then(response => response.json())
        .then(data => {
            const blogEntries = document.getElementById('blog-entries');
            blogEntries.innerHTML = ''; // Lösche den vorhandenen Inhalt, bevor neue Einträge hinzugefügt werden
            data.forEach(entry => {
                const entryDiv = document.createElement('div');
                entryDiv.innerHTML = `
                    <h3>${data.title}</h3>
                    <p>Author: ${data.author}</p>
                    <p>${data.content}</p>
                    <p>Created on: ${data.creationDate ? data.creationDate.toLocaleString() : ''}</p>

                `;
                blogEntries.appendChild(entryDiv);
            });
        });
}
// ...
